// create a new path
//*** your code ***//



// stylize: strokeWidth and strokeColor
//*** your code ***//


// number of points
var totalPoints = 50

// now use a for loop to add sinusoidal points to the path
// Math.sin(i) gives a sine value based on i
//*** your code ***//



// uncomment the following and check the outcome 
//path.selected = true;
//path.smooth({ type: 'continuous' });

