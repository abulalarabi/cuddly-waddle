// rectangle origin
//*** your code ***//



// set the size
//*** your code ***//



// create a rectangular path using new Path.Rectange(origin, size);
//*** your code ***//



// stylize: set strokeColor, fillColor and strokeWidth of the rectangle
//*** your code ***//



// remove the last segment using your_rectangle.removeSegment(index) method
//*** your code ***//

