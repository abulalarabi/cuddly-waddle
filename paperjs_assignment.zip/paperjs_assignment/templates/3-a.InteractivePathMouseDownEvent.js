// first lets create a new path
//*** your code ***//



// stylize: strokeColor, strokeWidth
//*** your code ***//



// we will add an event on mouse down
function onMouseDown(event) {
	
	// everytime the mouse is down, i.e., left-clicked,
	// we will add a new point to the path
	// the new point will be current pointer location
	// event has a property called point
	// thus, event.point gives the clicked coordinate

	// add the event.point to your path
	//*** your code ***//

	
	// change color based on pointer location
	//*** your code ***//

	
	// uncomment the following and check the outcome
	//path.selected = true;
	//path.smooth({ type: 'continuous' });
}

