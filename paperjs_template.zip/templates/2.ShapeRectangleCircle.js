// rectangle origin and geometry
// create an origin point using new Point(x,y);
//*** your code ***//



// create a size using new Size(width,height);
//*** your code ***//



// create a rectangular path using new Path.Rectangle(origin, size);
//*** your code ***//



// stylize: set strokeColor and strokeWidth of the path
//*** your code ***//
