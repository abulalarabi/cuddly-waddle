// circle origin
// create an origin point using new Point(x,y);
//*** your code ***//



// set the radius
//*** your code ***//



// create a circular path using new Path.Circle(origin, radius);
//*** your code ***//



// stylize: set strokeColor, fillColor and strokeWidth of the circle
//*** your code ***//



// remove the last segment using your_circle.removeSegment(index) method
//*** your code ***//

