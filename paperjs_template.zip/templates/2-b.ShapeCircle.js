// circle origin and geometry
// create an origin point using new Point(x,y);
//*** your code ***//


// set radius which is just a constant
//*** your code ***//



// create a circular path using new Path.Circle(origin, radius);
//*** your code ***//



// stylize: strokeColor, strokeWidth
//*** your code ***//



// remove the last segment using your_path.removeSegment(index)
//*** your code ***//

